package com.example.weighloss_proj_george_kaline;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

public interface  UserDAO {
    @query("Select * FROM user")
    List<User> getAll();

    @Query("Select")
}
