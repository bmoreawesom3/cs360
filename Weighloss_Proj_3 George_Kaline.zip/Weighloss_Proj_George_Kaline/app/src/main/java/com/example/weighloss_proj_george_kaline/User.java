package com.example.weighloss_proj_george_kaline;

import java.util.List;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;



public class User {

    public int uid;


    public String userName;


    public String passWord;
}
